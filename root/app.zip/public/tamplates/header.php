<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="DGBTS,gaming">
    <meta name="keywords" content="">
    <meta name="author" content="Crusial Designs">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DGBTS GAMING</title>
    <link rel="stylesheet" href="css/main.css">
    <script src="https://use.fontawesome.com/3571e1e4e4.js"></script>
    <script
            src="https://code.jquery.com/jquery-3.2.1.js"
            integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
            crossorigin="anonymous"></script>
</head>
<body>
    <div class="wrapper">
            <header>
                <div class="headertop flex-center align-center">
                </div>
                <div class="navbar flex-center">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="overons.php">About me</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
            </header>