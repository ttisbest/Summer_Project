<?php
/**
 * Created by PhpStorm.
 * User: Gebruiker
 * Date: 4-5-2017
 * Time: 11:31
 */
DEFINE ("DB_user", "root");
DEFINE ("DB_PASSWORD", "");
DEFINE ("DB_HOST", "localhost");
DEFINE ("DB_NAME", "project_fifa");
DEFINE ("DB_CHARSET", "utf8");
?>