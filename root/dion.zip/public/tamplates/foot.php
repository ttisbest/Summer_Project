        <footer>
            <div class="foot-content">
                <ul>
                    <li><a href="https://twitter.com/DGBTSGAMING" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                    <li><a href="https://www.youtube.com/channel/UC-mfPzs8PTZexVAoquKdPuA" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
                    <li><a href="https://www.twitch.tv/dgbts" target="_blank"><i class="fa fa-twitch" aria-hidden="true"></i></a></li>
                    <li><a href="https://www.tipeeestream.com/dgbts/donation" target="_blank"><i class="fa fa-paypal" aria-hidden="true"></i></a></li>
                    <li><a href="https://steamcommunity.com/tradeoffer/new/?partner=101433532&token=uqf0VDpo" target="_blank"><i class="fa fa-steam" aria-hidden="true"></i></a></li>
                </ul>
            </div>
                   <div class="copyright align-center">
                       <h4>Copyright &copy; 2017, DGBTS Editors</h4>
                </div>
        </footer>
    </div>

</body>
</html>
