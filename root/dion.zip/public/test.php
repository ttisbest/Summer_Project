<?php
include_once ("../app/skins/skinrmd.php");
