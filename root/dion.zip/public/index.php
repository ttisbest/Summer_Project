
		<?php
            include_once ("tamplates/header.php");
        ?>
		<div class="main-content">
			<div class="about-items flex-around">
				<ul class="item">
					<li>
						<h2>
							Twitch
						</h2>
                        <div class="iframe-round">
                            <iframe class="roundings" src="https://player.twitch.tv/?channel=dgbts" frameborder="0" allowfullscreen="true" scrolling="no" height="378" width="600"></iframe><a href="https://www.twitch.tv/dgbts?tt_medium=live_embed&tt_content=text_link"></a>
                        </div>
                    </li>
				</ul>
                <ul class="item">
                    <li>
                        <h2>
                          Youtube
                        </h2>
                        <div class="iframe-round">
                            <iframe class="roundings" src="https://player.twitch.tv/?channel=dgbts" frameborder="0" allowfullscreen="true" scrolling="no" height="378" width="600"></iframe><a href="https://www.twitch.tv/dgbts?tt_medium=live_embed&tt_content=text_link"></a>
                        </div>
                    </li>
                </ul>
			</div>
        </div>
        <?php
            include_once ("tamplates/foot.php");
        ?>
